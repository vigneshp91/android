package com.example.vignesh.handler;

import android.os.Handler;
import android.os.HandlerThread;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
private Handler handler2,handler1;
    private Runnable runnable,runnable1;
    private Button logstop1,logstop2,logstart1,logstart2,status;
    HandlerThread handlerThread2 = new HandlerThread("HandlerThread_my");
    HandlerThread handlerThread1 = new HandlerThread("HandlerThread_my");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logstop1=(Button)findViewById(R.id.logstop1);
        logstop2=(Button)findViewById(R.id.logstop2);
        logstart1=(Button)findViewById(R.id.logstart1);
        logstart2=(Button)findViewById(R.id.logstart2);
        status=(Button)findViewById(R.id.status);
        logstop1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                handler1.removeCallbacks(runnable);
                handlerThread1.quit();
            }
        });

        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (handlerThread1.isAlive()) {
                    Toast.makeText(MainActivity.this, "first thread alive", Toast.LENGTH_SHORT).show();
                }else if(handlerThread2.isAlive()){
                    Toast.makeText(MainActivity.this, "second thread alive", Toast.LENGTH_SHORT).show();
                }else
                {
                    Toast.makeText(MainActivity.this, "all dead", Toast.LENGTH_SHORT).show();
                }

            }
        });

        logstop2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                handler2.removeCallbacks(runnable1);
                handlerThread2.quit();
            }
        });

        logstart1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                handler1.postDelayed(runnable, 10000);
            }
        });

        logstart2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                handler2.postDelayed(runnable1, 10000);
            }
        });


        // HandlerThread handlerThread = new HandlerThread("HandlerThread");
        handlerThread2.start();
        handlerThread1.start();
        handler2 = new Handler(handlerThread2.getLooper());
        handler1 = new Handler(handlerThread1.getLooper());
        runnable = new Runnable()
        {
            @Override
            public void run()
            {
                Log.d("running", "in delay");
                handler1.postDelayed(this, 2000);
            }
        };

        runnable1 = new Runnable()
        {
            @Override
            public void run()
            {
                Log.d("running", "in delay2");
                handler2.postDelayed(this, 4000);
            }
        };

       // handlerThread.quitSafely();
    }
}
